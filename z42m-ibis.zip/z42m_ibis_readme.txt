Z42M IBIS MODEL
-----------------
Device: 16Gb Mobile LPDDR4 SDRAM - Die Rev "B"
Architecture: 512Meg x 32
VDDQ = 0.60V/0.57V/0.65V; 1.10V/1.06V/1.17V
VDD2 = 1.10V/1.06V/1.17V

SOURCE
------------
Micron Technology, Inc.
For support contact your local Micron FAE/Sales contacts
(more information at https://www.micron.com/support/sales-network ).

REVISION HISTORY
----------------
Rev 1.0: 11/05/2020
       - First revision pre-silicon model from parasitic extracted netlist
       - Data tables extracted from HSPICE Model Rev 1.0
Rev 1.1: 01/20/2021
       - Added MT53E1G32D2NP, MT53E512M32D1NP
Rev 1.2: 03/16/2021
       - Fixed GND Clamp in Submodels for *_at.ibs, *_it.ibs and *_ut.ibs
         due to the wrong ODT value
Rev 1.3  04/12/2021
       - Changed the model name from PU** to SOC-ODT** in DQ/DQS driver
Rev 1.4  05/17/2021
       - Added MT53E512M64D2NW
Rev 1.5  05/24/2021
       - Added MT53E512M32D1FW
Rev 1.6  07/27/2021
       - Updated from MT53E512M32D1FW to MT53E512M32D1ZW
       - Added MT53E1G32D2FW
Rev 1.7  09/21/2021
       - Added MT53E512M64D2HJ
Rev 1.8  10/07/2021
       - Fixed the package model for MT53E512M32D1ZW
Rev 2.0  11/15/2021
       - Matched input capacitance to latest measurements
       - Matched I-V curves to latest measurements
       - Model data matches HSPICE model revision 2.0
Rev 2.1  03/07/2022
       - Added MT53E512M64D2NZ
Rev 2.2  06/22/2022
       - Added MT53E512M64D2RR
Rev 2.3  01/10/2023
       - Updated MT53E512M32D1ZW
Rev 2.4  04/17/2023
       - Renamed MT53E512M32D1ZW (2L) to MT53E512M32D1ZW_B
       - Added MT53E512M32D1ZW (4L)

Part Number        #Die  #Channel  #DQ  Package                               HSPICE package Model
---------------    ----  --------  ---  -------                               ---------
MT53E512M32D1NP     1      2        32  200-ball SDP WFBGA 10x14.5x0.8mm      z42m_200b_sdp_sb_pkg.sp
MT53E512M32D1ZW     1      2        32  200-ball SDP TFBGA 10x14.5x1.05mm 4L  N/A
MT53E512M32D1ZW_B   1      2        32  200-ball SDP TFBGA 10x14.5x1.05mm 2L  z42m_200b_sdp_lb2_pkg.sp
MT53E512M64D2NZ     2      4        64  376-ball DDP VFBGA 14x14x0.71mm       z42m_376b_ddp_pkg.sp
MT53E512M64D2NW     2      4        64  432-ball DDP VFBGA 15x15x0.85mm       z42m_432b_ddp_pkg.sp
MT53E512M64D2HJ     2      4        64  556-ball DDP TFBGA 12.4x12.4x1.1mm    z42m_556b_ddp_1p1mm_pkg.sp
MT53E512M64D2RR     2      4        64  556-ball DDP WFBGA 12.4x12.4x0.72mm   z42m_556b_ddp_pkg.sp
MT53D512M32D1Z42M   1      2        32  Bare Die for VDDQ=0.6V                N/A
MT53B512M32D1Z42M   1      2        32  Bare Die for VDDQ=1.1V                N/A


Part Number        #Die  #Channel  #DQ  Package                           S-parameter Package Model
---------------    ----  --------  ---  -------                           ---------
MT53E1G32D2FW       2      2        32  200-ball DDP TFBGA 10x14.5x1.1mm  z42m_200b_ddp_FW_4GB_S-parameter.zip
MT53E1G32D2NP       2      2        32  200-ball DDP WFBGA 10x14.5x0.8mm  z42m_200b_ddp_NP_4GB_S-parameter.zip

Please download the S-parameter Package Model from the following URL.

z42m_200b_ddp_FW_4GB_S-parameter.zip:
https://www.micron.com/-/media/client/global/documents/products/sim-model/dram/lpddr4/z42m_200b_ddp_FW_4GB_S-parameter.zip

z42m_200b_ddp_NP_4GB_S-parameter.zip:
https://www.micron.com/-/media/client/global/documents/products/sim-model/dram/lpddr4/z42m_200b_ddp_NP_4GB_S-parameter.zip


NOTES
-----   

 - z42m_0p6v_wt.ibs is IBIS V5.0 applicable to 0.6V VDDQ Wireless Temperature Range -25C<=Ta<=85C
   z42m_0p6v_at.ibs is IBIS V5.0 applicable to 0.6V VDDQ Automotive Temperature Range -40C<=Ta<=105C
   z42m_0p6v_it.ibs is IBIS V5.0 applicable to 0.6V VDDQ Industrial Temperature Range -40C<=Ta<=95C
   z42m_0p6v_ut.ibs is IBIS V5.0 applicable to 0.6V VDDQ Automotive Ultra Temperature Range -40C<=Ta<=125C
   z42m_1p1v_wt.ibs is IBIS V5.0 applicable to 1.1V VDDQ Wireless Temperature Range -25C<=Ta<=85C
   z42m_1p1v_at.ibs is IBIS V5.0 applicable to 1.1V VDDQ Automotive Temperature Range -40C<=Ta<=105C
   z42m_1p1v_it.ibs is IBIS V5.0 applicable to 1.1V VDDQ Industrial Temperature Range -40C<=Ta<=95C
   z42m_1p1v_ut.ibs is IBIS V5.0 applicable to 1.1V VDDQ Automotive Ultra Temperature Range -40C<=Ta<=125C

 - The IBIS model includes On Die Termination (ODT) characteristics.  ODT is
   modeled through the use of [Submodel] ground clamp I-V curves that
   add the termination characteristics to the regular power and ground clamp
   characteristics when the I/O is functioning as an input.  ODT applies to the
   DQ, DQS_t/DQS_c, DMI, CA, and CK signals.  Use the [Model Selector] to 
   choose between 40, 48, 60, 80, 120 or 240 ohm ODT settings.

 - The DQ_PD* and DQS_PD* models should be used for output.
   The DQ_ODT* and DQS_ODT* models should be used for input.

 - During Single-Ended DQS read mode, data input for DQS_c must be 0V.

 - The EBD model does not include signal coupling and is not accurate for differential signals.
   It is recommended to perform a final simulation checkout with an S-parameter package model.
   S-parameter package models may be available for download or can be requested directly
   from your Micron representative or through the Micron technical support request form at
   https://www.micron.com/forms/technical-support-contact .


Notes on IBIS 5.0 Power Aware IBIS features:
--------------------------------------------

1. The on-die VDDQ-VSS decoupling circuit for DQ and DQS MUST be included 
   externally to the IBIS model.  Two options are available using the 
   following Spice subcircuits:

   a. z42m_ondie_decoupling_alldq.ckt - includes VDDQ-VSS decoupling for all signals 
      including DQ[0-15]_A/B, DQS[0:1]_t_A/B, DQS[0:1]_c_A/B, and DMI[0:1]_A/B.
      1 instance of this circuit is equivalent to 1 die.

   b. z42m_ondie_decoupling_perchdq.ckt - includes VDDQ-VSS decoupling for 1 channel signals 
      including DQ[0-15]_A or B, DQS[0:1]_t_A or B, DQS[0:1]_c_A or B, and DMI[0:1]_A or B.
      2 instance of this circuit is equivalent to 1 die.

   c. z42m_ondie_decoupling_perdq.ckt - includes VDDQ-VSS decoupling for an
      individual signal such as DQ[0-15]_A/B, DQS[0:1]_t_A/B, DQS[0:1]_c_A/B, and DMI[0:1]_A/B.
      This circuit is useful for correlation simulations comparing the IBIS model
      and the Spice model for a single I/O.  44 instances of this subcircuit
      in parallel is equivalent to the z42m_ondie_decoupling_alldq.ckt circuit.
      22 instances of this subcircuit in parallel is equivalent to
      the z42m_ondie_decoupling_perchdq.ckt circuit.

   Correct usage of these subcircuits requires adding them across the IBIS DQ 
   and DQS models' [Pullup Reference] and [Pulldown Reference] nodes (the die 
   power and ground pads inside of any package model).  Reference the .ckt 
   files for a Spice simulator example.

2. Due to the inclusion of [Composite Current] I-t waveforms, overclocking of 
   Models may be required, as the V-t and I-t waveforms are longer than the 
   bit period in some cases.

3. [Composite Current] and [ISSO *] data tables included for all DQ and DQS
   driver models.
   
4. If simulating the IBIS model in HSpice, it is recommended to use 2013.03 or 
   newer version.


[Disclaimer] This software code and all associated documentation, comments
             or other information (collectively "Software") is provided 
             "AS IS" without warranty of any kind. MICRON TECHNOLOGY, INC. 
             ("MTI") EXPRESSLY DISCLAIMS ALL WARRANTIES EXPRESS OR IMPLIED,
             INCLUDING BUT NOT LIMITED TO, NONINFRINGEMENT OF THIRD PARTY
             RIGHTS, AND ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS
             FOR ANY PARTICULAR PURPOSE. MTI DOES NOT WARRANT THAT THE
             SOFTWARE WILL MEET YOUR REQUIREMENTS, OR THAT THE OPERATION OF
             THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE. FURTHERMORE,
             MTI DOES NOT MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE
             RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS,
             ACCURACY, RELIABILITY, OR OTHERWISE. THE ENTIRE RISK ARISING OUT
             OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS WITH YOU. IN NO
             EVENT SHALL MTI, ITS AFFILIATED COMPANIES OR THEIR SUPPLIERS BE
             LIABLE FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL, INCIDENTAL, OR
             SPECIAL DAMAGES (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
             OF PROFITS, BUSINESS INTERRUPTION, OR LOSS OF INFORMATION)
             ARISING OUT OF YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
             EVEN IF MTI HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
             Because some jurisdictions prohibit the exclusion or limitation
             of liability for consequential or incidental damages, the above
             limitation may not apply to you.
 
             Copyright 2023 Micron Technology, Inc. All rights reserved.
